import { defineConfig, loadEnv } from "vite";
import reactRefresh from "@vitejs/plugin-react-refresh";
import svgrPlugin from "vite-plugin-svgr";

export default ({ mode }) => {
  process.env = { ...process.env, ...loadEnv(mode, process.cwd()) };

  return defineConfig({
    plugins: [
      reactRefresh(),
      svgrPlugin({
        svgrOptions: {
          icon: true,
        },
      }),
    ],
    server: {
      port: 5000,
      host: "0.0.0.0",
    },
    build: {
      outDir: "build",
    },
    define: {
      "process.env.VITE_APP_COLOUR": JSON.stringify(
        process.env.VITE_APP_COLOUR
      ),
    },
  });
};
