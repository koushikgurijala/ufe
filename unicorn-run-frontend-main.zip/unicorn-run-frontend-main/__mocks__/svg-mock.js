export default "SvgrURL";
export const ReactComponent = "div";
