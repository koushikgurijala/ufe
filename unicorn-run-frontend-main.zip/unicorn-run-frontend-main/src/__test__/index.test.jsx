import React from "react";
import { render } from "@testing-library/react";

import App from "../App";

describe("Application root", () => {
  it("Renders without crashing", () => {
    const { container } = render(<App />);
    expect(container.textContent).toBe(
      "LeaderboardDailyWeeklyAll TimeRecentName: SaveYour score had been saved!Play AgainEngineering Productivity"
    );
  });
});
