import React from "react";
import App from "../App";
import { unmountComponentAtNode } from "react-dom";
import renderer from "react-test-renderer";
import { render } from "@testing-library/react";
import { act } from "react-dom/test-utils";

let container = null;
beforeEach(() => {
  // Setup a DOM element as a render target
  container = document.createElement("div");
  document.body.appendChild(container);
});

afterEach(() => {
  // Cleanup on exiting
  unmountComponentAtNode(container);
  container.remove();
  container = null;
});

it("App Renders correctly", () => {
  const tree = renderer.create(<App></App>).toJSON();
  expect(tree).toMatchSnapshot();
});

it("Checks if app consists of all components", () => {
  act(() => {
    render(<App></App>, container);
  });
  const mainDiv = document.querySelector("[data-testid=app]");
  expect(mainDiv.childElementCount).toBe(2);
});
