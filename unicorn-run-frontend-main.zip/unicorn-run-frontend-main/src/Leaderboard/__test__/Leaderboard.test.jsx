import React from "react";
import { render, fireEvent } from "@testing-library/react";
import { unmountComponentAtNode } from "react-dom";
import renderer from "react-test-renderer";
import { act } from "react-dom/test-utils";
import Leaderboard from "../Leaderboard";

let container = null;
beforeEach(() => {
  // Setup a DOM element as a render target
  container = document.createElement("div");
  document.body.appendChild(container);
});

afterEach(() => {
  // Cleanup on exiting
  unmountComponentAtNode(container);
  container.remove();
  container = null;
});

it("Leaderboard Component Renders correctly", () => {
  const tree = renderer.create(<Leaderboard></Leaderboard>).toJSON();
  expect(tree).toMatchSnapshot();
});

it("Checks if a radio button is clickable", () => {
  act(() => {
    render(<Leaderboard></Leaderboard>, container);
  });
  const buttons = document.getElementsByName("tab");
  expect(allNotChecked(buttons)).toBe(true);
  fireEvent.click(buttons[1]);
  expect(buttons[0]).not.toBeChecked();
  expect(buttons[1]).toBeChecked();
  expect(buttons[2]).not.toBeChecked();
  expect(buttons[3]).not.toBeChecked();
});

function allNotChecked(buttons) {
  for (const button in buttons) {
    if (button.checked) {
      return false;
    }
  }
  return true;
}
