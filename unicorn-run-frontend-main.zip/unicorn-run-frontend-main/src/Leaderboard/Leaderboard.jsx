import React from "react";
import "./Leaderboard.css";

function Leaderboard() {
  return (
    <div className="topcorner">
      <p>
        <strong>Leaderboard</strong>
      </p>
      <br></br>
      <div className="tab-frame">
        <input type="radio" name="tab" id="tab1" />
        <label htmlFor="tab1" className="tab">
          Daily
        </label>

        <input type="radio" name="tab" id="tab2" />
        <label htmlFor="tab2" className="tab">
          Weekly
        </label>

        <input type="radio" name="tab" id="tab3" />
        <label htmlFor="tab3" className="tab">
          All Time
        </label>

        <input type="radio" name="tab" id="tab4" />
        <label htmlFor="tab4" className="tab">
          Recent
        </label>

        <div className="tab">
          <table id="id02"></table>
        </div>
        <div className="tab">
          <table id="id03"></table>
        </div>
        <div className="tab">
          <table id="id01"></table>
        </div>
        <div className="tab">
          <table id="id04"></table>
        </div>
      </div>
    </div>
  );
}

export default Leaderboard;
