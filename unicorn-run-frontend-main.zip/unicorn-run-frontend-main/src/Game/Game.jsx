import React from "react";
import spritesx100 from "./100-offline-sprite.png";
import spritesx200 from "./200-offline-sprite.png";
import "./Game.css";

function Game(props) {
  const colour = props.colour;
  const engprod = () => {
    if (colour === "green") {
      return (
        <div data-testid="green-gradient" className="green">
          <p className="appName2">
            <strong>Engineering Productivity</strong>
          </p>
        </div>
      );
    } else if (colour === "purple") {
      return (
        <div data-testid="purple-gradient" className="purple">
          <p className="appName2">
            <strong>Engineering Productivity</strong>
          </p>
        </div>
      );
    } else {
      return (
        <p data-testid="no-gradient" className="appName">
          <strong>Engineering Productivity</strong>
        </p>
      );
    }
  };

  return (
    <div id="main-frame-error" className="interstitial-wrapper">
      <div id="main-content">
        <div className="icon icon-offline" alt=""></div>
      </div>
      <div className="center" id="offline-resources">
        <img id="offline-resources-1x" src={spritesx100} alt="sprites1x" />
        <img id="offline-resources-2x" src={spritesx200} alt="sprites2x" />
      </div>
      <br></br>
      <div>
        <div data-testid="input-form" className="item1">
          <div id="inputbox" className="input">
            Name:{" "}
            <input
              data-testid="name-input"
              id="nickname"
              defaultValue={""}
              maxLength="10"
            />
            <input id="hiddenscore" type="hidden" value="" />
            <button data-testid="save-button" className="button" disabled>
              Save
            </button>
          </div>
          <div id="submitted" className="saved">
            Your score had been saved!
          </div>
          <div id="leaderboardimg" className="leaderboard">
            <a data-testid="home-link" href="/" className="item2">
              Play Again
            </a>
          </div>
          <br></br>
          {engprod()}
        </div>
      </div>
    </div>
  );
}

export default Game;
