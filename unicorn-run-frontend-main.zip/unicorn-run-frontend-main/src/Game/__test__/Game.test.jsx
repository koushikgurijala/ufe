import React from "react";
import { render, fireEvent } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { unmountComponentAtNode } from "react-dom";
import renderer from "react-test-renderer";
import { act } from "react-dom/test-utils";
import Game from "../Game";

let container = null;
beforeEach(() => {
  container = document.createElement("div");
  document.body.appendChild(container);
});

afterEach(() => {
  unmountComponentAtNode(container);
  container.remove();
  container = null;
});

it("Game Component Renders correctly", () => {
  const tree = renderer.create(<Game></Game>).toJSON();
  expect(tree).toMatchSnapshot();
});

it("Changes engineering productivity sign to no background", () => {
  act(() => {
    render(<Game colour="plain"></Game>, container);
  });
  const background = document.querySelector("[data-testid=no-gradient]");
  expect(background).toBeTruthy();
  expect(document.querySelector("[data-testid=green-gradient]")).toBeNull();
  expect(document.querySelector("[data-testid=purple-gradient]")).toBeNull();
});

it("Changes engineering productivity sign to green background", () => {
  act(() => {
    render(<Game colour="green"></Game>, container);
  });
  const background = document.querySelector("[data-testid=green-gradient]");
  expect(background).toBeTruthy();
  expect(document.querySelector("[data-testid=no-gradient]")).toBeNull();
  expect(document.querySelector("[data-testid=purple-gradient]")).toBeNull();
});

it("Changes engineering productivity sign to purple background", () => {
  act(() => {
    render(<Game colour="purple"></Game>, container);
  });
  const background = document.querySelector("[data-testid=purple-gradient]");
  expect(background).toBeTruthy();
  expect(document.querySelector("[data-testid=green-gradient]")).toBeNull();
  expect(document.querySelector("[data-testid=no-gradient]")).toBeNull();
});

it("Checks if form is available", () => {
  act(() => {
    render(<Game colour="plain"></Game>, container);
  });
  const form = document.querySelector("[data-testid=input-form]");
  expect(form).toBeTruthy();
});

it("Checks the nickname input field", () => {
  const { getByTestId } = render(<Game colour="plain"></Game>, container);
  expect(getByTestId("name-input").value).toBe("");
  fireEvent.change(getByTestId("name-input"), { target: { value: "TESTER" } });
  expect(getByTestId("name-input").value).toBe("TESTER");
});

it("Checks the nickname input field can only enter 10 characters", async () => {
  const { getByTestId } = render(<Game colour="plain"></Game>, container);
  expect(getByTestId("name-input").value).toBe("");
  await userEvent.type(getByTestId("name-input"), "TESTERRRRRZZZZZZ");
  expect(getByTestId("name-input").value).toBe("TESTERRRRR");
});

it("Checks if save button is disabled before name is entered", () => {
  const { getByTestId } = render(<Game colour="plain"></Game>, container);
  expect(getByTestId("save-button")).toBeDisabled();
});

it("Checks if play again link goes back to home screen", () => {
  const { getByTestId } = render(<Game colour="plain"></Game>, container);
  expect(getByTestId("home-link")).toHaveAttribute("href", "/");
});
