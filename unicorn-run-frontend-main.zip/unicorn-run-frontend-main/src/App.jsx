import React from "react";
import "./App.css";
import Game from "./Game/Game";
import Leaderboard from "./Leaderboard/Leaderboard";

function App() {
  return (
    <div data-testid="app" className="App">
      <Leaderboard />
      <Game colour={process.env.VITE_APP_COLOUR} />
    </div>
  );
}

export default App;
