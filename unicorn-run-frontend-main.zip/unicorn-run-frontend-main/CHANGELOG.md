# Changelog

## [1.21.0](https://github.com/telus/unicorn-run-frontend/compare/v1.20.0...v1.21.0) (2022-06-29)


### :rocket: Features

* testing features section ([ea173ff](https://github.com/telus/unicorn-run-frontend/commit/ea173ff6aea8e0e464a5f0d3737ad3efaf7227ef))


### :spider: Bug Fixes

* testing fixes section ([d1dd193](https://github.com/telus/unicorn-run-frontend/commit/d1dd19353bf68a234120e6870f66bf602b4b03a2))


### :compass: Miscellaneous

* testing chores section ([f4fb15b](https://github.com/telus/unicorn-run-frontend/commit/f4fb15b6976f55c61a2304922a9fa00e53c3c788))
