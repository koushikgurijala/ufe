window.addEventListener("load", function getLeaderboardScores() {
  var xmlhttp = new XMLHttpRequest();
  var url = "/scoreManagement/v1/score?range=alltime";

  xmlhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      var myArr = JSON.parse(this.responseText);
      myFunction(myArr);
    }
  };

  xmlhttp.open("GET", url, true);
  xmlhttp.send();

  function myFunction(arr) {
    var out = "";
    var i;
    for (i = 0; i < arr.length; i++) {
      out +=
        "<tr><td>" +
        "#" +
        [i + 1] +
        "</td>" +
        "<td>" +
        arr[i].nickname +
        "</td>" +
        "<td>" +
        arr[i].score +
        "</td></tr>";
      document.getElementById("id01").innerHTML = out;
    }
  }
  var xmlhttp2 = new XMLHttpRequest();
  var url2 = "/scoreManagement/v1/score?range=daily";

  xmlhttp2.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      var myArr2 = JSON.parse(this.responseText);
      myFunction2(myArr2);
    }
  };

  xmlhttp2.open("GET", url2, true);
  xmlhttp2.send();

  function myFunction2(arr2) {
    var out2 = "";
    var ii;
    for (ii = 0; ii < arr2.length; ii++) {
      out2 +=
        "<tr><td>" +
        "#" +
        [ii + 1] +
        "</td>" +
        "<td>" +
        arr2[ii].nickname +
        "</td>" +
        "<td>" +
        arr2[ii].score +
        "</td></tr>";
      document.getElementById("id02").innerHTML = out2;
    }
  }
  var xmlhttp3 = new XMLHttpRequest();
  var url3 = "/scoreManagement/v1/score?range=weekly";

  xmlhttp3.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      var myArr3 = JSON.parse(this.responseText);
      myFunction3(myArr3);
    }
  };

  xmlhttp3.open("GET", url3, true);
  xmlhttp3.send();

  function myFunction3(arr3) {
    var out3 = "";
    var iii;
    for (iii = 0; iii < arr3.length; iii++) {
      out3 +=
        "<tr><td>" +
        "#" +
        [iii + 1] +
        "</td>" +
        "<td>" +
        arr3[iii].nickname +
        "</td>" +
        "<td>" +
        arr3[iii].score +
        "</td></tr>";
      document.getElementById("id03").innerHTML = out3;
    }
  }
  var xmlhttp4 = new XMLHttpRequest();
  var url4 = "/scoreManagement/v1/score?range=recent";

  xmlhttp4.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      var myArr4 = JSON.parse(this.responseText);
      myFunction4(myArr4);
    }
  };

  xmlhttp4.open("GET", url4, true);
  xmlhttp4.send();

  function myFunction4(arr4) {
    var out4 = "";
    var iiii;
    for (iiii = 0; iiii < arr4.length; iiii++) {
      out4 +=
        "<tr><td>" +
        "#" +
        [iiii + 1] +
        "</td>" +
        "<td>" +
        arr4[iiii].nickname +
        "</td>" +
        "<td>" +
        arr4[iiii].score +
        "</td></tr>";
      document.getElementById("id04").innerHTML = out4;
    }
  }
});
