---
name: TASK
about: All tasks require enough detail that theoretically anybody could pick up the
  task and work on it.
title: ''
labels: TASK
assignees: ''

---

A task should be possible to complete within one day, by one person.
- Reference this task within exactly one EPIC
- Assign one PROJECT (purple) label to the task, matching the EPIC
- Ensure the task is added to the Engineering Productivity Project Management project 57

# OUTCOME
Describe the desired outcome, what does success look like?

# ADDITIONAL NOTES
Provide any additional background on what we're trying to achieve with this task.

# ACCEPTANCE CRITERIA
How will we know when this task is completed?
