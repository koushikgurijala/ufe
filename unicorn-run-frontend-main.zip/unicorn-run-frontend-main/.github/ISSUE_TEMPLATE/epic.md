---
name: EPIC
about: A capability or win that we will deliver, with various sub-tasks
title: "[EPIC] title"
labels: EPIC
assignees: ''

---

An EPIC is a capability or win that we will deliver, with various sub-tasks. Duration is not a factor, instead focus on from a reporting perspective if we would want to count this as a deliverable.
- Assign at least one PROJECT (purple) label
- Assign either the Win or Capability (pink) label
- Assign a Quarter (blue) label
- Ensure the EPIC is added to the Engineering Productivity Project Management project 57

# User Stories
- **As a** first responder **I need to** get the location of my patient **so that I can** respond to their emergency health care needs as quickly as possible.

# Impact
Describe in concrete terms how this capability/win will provide value.

# Background
Example: Message handling has been going through the Aepone Accellerite platform for years. The platform has been configured a number of times and consumers are largely satisfied with the service. Unfortunately the current version has been deprecated for a number of years and fully unsupported for at least two. The platform provides critical services to emergency providers, fraud teams, and fleet managers among others and the risks associated with the platform failing are considerable.

# Acceptance Criteria
- Example: Allow consumer applications to use a RESTful OneAPI Terminal Location interface to get a location for one or more customer terminals.

# Out of Scope
- Example: Enhancing the performance and feature set above and beyond the current baseline

# Implementation Notes
Example: Swagger spec, style guide, library, etc.
## Solution Design
Link to diagram if applicable
## Example Request & Response
If applicable

# References & Resources
| Description | Link |
| ------------- | ----- |

# Tasks
- [ ] list of subtask issues
