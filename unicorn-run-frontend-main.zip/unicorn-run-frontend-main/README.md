# :unicorn: UnicornRun Frontend

This is the frontend for the Unicorn Run reference application. It is an adaptation of the Chrome Dino game that we all know and love, but with a TELUS and Engineering Productivity(EP) twist. It will be used as a playground for all things related to GitHub actions.

## Technologies Used

The frontend of UnicornRun was made using:

- Javascript
- ReactJS
- packaged using ViteJS :zap:
